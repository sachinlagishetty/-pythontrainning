#!/usr/bin/env python
# coding: utf-8

# In[7]:


import re
def phonenumbervalidate(phone):
    pattern='^[+][9][1][6-9][0-9]{9}$'
    phone=str(phone)
    if re.match(pattern,phone):
        return True
    return False
print(phonenumbervalidate("+919988554931"))
print(phonenumbervalidate(9955441))


# In[10]:


import re
def validaterollnumber(number):
    
    number=str(number)
    pattern="^[1][5][2][u][1][A][0][1-9][0-6][0-9]"
    if re.match(pattern,number):
        return True
    return False
print(validaterollnumber("152U1A0555"))
print(validaterollnumber("152U1A0485"))


# In[ ]:




