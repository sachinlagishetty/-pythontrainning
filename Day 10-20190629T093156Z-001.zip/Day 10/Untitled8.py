#!/usr/bin/env python
# coding: utf-8

# In[9]:


def createfile(filename):
    f=open(filename,"w")
    for i in range(10):
        f.write("this is %d line\n"%i)
    print("file is created successfully and data is written")
    f.close()
    return
createfile("file1.txt")
    
    


# In[7]:


def readfile(filename):
    f=open(filename,"r")
    if f.mode=="r":
        x=f.read()
        print (x)
    f.close()
    return
readfile("file1.txt")


# In[ ]:





# In[ ]:





# In[ ]:




