#!/usr/bin/env python
# coding: utf-8

# In[11]:


def printEven(n):
    cnt=0;
    sum=0;
    while(cnt!=n):
        if(cnt%2==0):
            sum=sum+cnt;
        cnt=cnt+1;
    return sum;
print(printEven(20));        


# In[13]:


def factorlist(n):
    i=1;
    while(i!=n):
        if(n%i==0):
            print(i,end=" ");
        i=i+1;
    return;
factorlist(12);


# In[15]:


list1=[1,2,3,4,5];
#entire list
print(list1);
#list[0]
print(list1[0])


# In[18]:


lst1=[1,2,3,4,5,6];
for x in lst1:
    print(x,end=" ")
print(lst1[4]);
print(lst1[3:6]);


# In[22]:


lst1=[1,2,3,4,5,6,7,8,9,10]
for x in lst1:
    print(x,end=" ");
print();
print(lst1[1:-1]);
print(lst1[::2]);
print(lst1[::3]);
print(lst1[-4]);


# In[25]:


lst1=[1,2,3,4,5];
print(lst1)
del lst1[2];
print(lst1)
#lst1[4]=15;
print(len(lst1));#used to find the len of lst
lst1.append(15);
print(lst1);


# In[32]:


def linearExample2(a,tarItem):
    
    for i in range(len(a)):
        if a[i]==tarItem:
            j=0
            while j!=i+1:
                print("!",end=" ")
                j=j+1;
            print(end=" ");
            
a=[1,5,9,5,15,12,5]
linearExample2(a,5)


# In[33]:


def linearformattedoutput(a):
    for i in range(len(a)):
        if i==0 or i==(len(a)-1):
            print(a[i],end=" ")
        else:
            print(a[i-1]*a[i+1],end=" ")
            
a=[1,2,3,4,5]
linearformattedoutput(a);


# In[35]:


def linearformattedoutput(a):
    for i in range(len(a)):
        if i==0 or (i==len(a)-1):
            print(a[i],end=" ")
        elif a[i-1]%2==0 and a[i+1]%2==0:
                print(a[i],end=" ")
a=[1,6,9,4,16,19,22]
linearformattedoutput(a);


# In[43]:


def numbertolistconversion(n):
    lst=[]
    string=str(n)
    for i in string:
        lst.append(int(i))
#     while n!=0:
#         r=n%10
#         lst.append(r)
#         n=n//10
#     lst.reverse()
    print(lst)
    
    
    
n=int(input("enter a number"))
numbertolistconversion(n)


# In[ ]:



    
     


# In[ ]:




